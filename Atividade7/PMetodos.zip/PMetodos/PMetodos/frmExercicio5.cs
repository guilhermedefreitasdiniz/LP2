﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnRealizaSorteio_Click(object sender, EventArgs e)
        {
            int num1, num2;

            if(!int.TryParse(txtPrimeiroNumero.Text, out num1)|| !int.TryParse(txtSegundoNumero.Text, out num2))
            {
                MessageBox.Show("Números Invalidos");
               
          
            }
            else
            {
                if(num1 > num2)
                {
                    MessageBox.Show("Número 2 deve ser maior que o número 1");

                }
                if ((num1 <= 0) || (num2 <= 0))
                {
                    MessageBox.Show("Número não pode ser 0");

                }
                else
                {
                    Random objrandom = new Random();
                    int aleatorio = objrandom.Next(num1, num2);
                    MessageBox.Show("Número gerado foi: " + aleatorio);
                }
            }
               
        }
    }
}
