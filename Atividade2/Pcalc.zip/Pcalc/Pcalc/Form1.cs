﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {


            if (MessageBox.Show("..vai sair mesmo ? :(",
            "Saída", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question)==
                DialogResult.Yes)

            {
                Close();
            }
        }

        private void TxtNumerodois_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumerodois.Text, out numero2))
            {

                MessageBox.Show("Número Inválido");
                txtNumerodois.Focus();
            }
            
        }

        private void BtnMais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnMulti_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("não pode dividir por zero!!!", "Seu cabeça de bagre...",
                MessageBoxButtons.OK,MessageBoxIcon.Hand);

                txtNumerodois.Focus();
            }
            else
            {
            resultado = numero1 / numero2;
            txtResultado.Text = resultado.ToString();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNumeroum.Clear();
            txtNumerodois.Text = "";
            txtResultado.Text = String.Empty;

            txtNumeroum.Focus();

            resultado = 0;
           
        }

        private void TxtNumeroum_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumeroum.Text, out numero1))
            {
                MessageBox.Show("Número Inválido");
                txtNumeroum.Focus();
            }
    
        }
    }
}
