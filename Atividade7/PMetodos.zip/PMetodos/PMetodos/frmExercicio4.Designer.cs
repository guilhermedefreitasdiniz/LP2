﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNumeros = new System.Windows.Forms.Button();
            this.btnPrimeiroCarac = new System.Windows.Forms.Button();
            this.btnContaLetras = new System.Windows.Forms.Button();
            this.lblFrase = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rctxtFrase
            // 
            this.rctxtFrase.Font = new System.Drawing.Font("Orator Std", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rctxtFrase.Location = new System.Drawing.Point(18, 71);
            this.rctxtFrase.Name = "rctxtFrase";
            this.rctxtFrase.Size = new System.Drawing.Size(744, 438);
            this.rctxtFrase.TabIndex = 0;
            this.rctxtFrase.Text = "";
            // 
            // btnContaNumeros
            // 
            this.btnContaNumeros.Font = new System.Drawing.Font("Orator Std", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaNumeros.Location = new System.Drawing.Point(781, 71);
            this.btnContaNumeros.Name = "btnContaNumeros";
            this.btnContaNumeros.Size = new System.Drawing.Size(307, 86);
            this.btnContaNumeros.TabIndex = 1;
            this.btnContaNumeros.Text = "Conta Letras";
            this.btnContaNumeros.UseVisualStyleBackColor = true;
            this.btnContaNumeros.Click += new System.EventHandler(this.BtnContaNumeros_Click);
            // 
            // btnPrimeiroCarac
            // 
            this.btnPrimeiroCarac.Font = new System.Drawing.Font("Orator Std", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrimeiroCarac.Location = new System.Drawing.Point(781, 172);
            this.btnPrimeiroCarac.Name = "btnPrimeiroCarac";
            this.btnPrimeiroCarac.Size = new System.Drawing.Size(307, 86);
            this.btnPrimeiroCarac.TabIndex = 2;
            this.btnPrimeiroCarac.Text = "Primeiro Caracter";
            this.btnPrimeiroCarac.UseVisualStyleBackColor = true;
            this.btnPrimeiroCarac.Click += new System.EventHandler(this.BtnPrimeiroCarac_Click);
            // 
            // btnContaLetras
            // 
            this.btnContaLetras.Font = new System.Drawing.Font("Orator Std", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaLetras.Location = new System.Drawing.Point(781, 286);
            this.btnContaLetras.Name = "btnContaLetras";
            this.btnContaLetras.Size = new System.Drawing.Size(307, 86);
            this.btnContaLetras.TabIndex = 3;
            this.btnContaLetras.Text = "Conta Numeros";
            this.btnContaLetras.UseVisualStyleBackColor = true;
            this.btnContaLetras.Click += new System.EventHandler(this.BtnContaLetras_Click);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Font = new System.Drawing.Font("Orator Std", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrase.Location = new System.Drawing.Point(12, 32);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(100, 36);
            this.lblFrase.TabIndex = 4;
            this.lblFrase.Text = "Frase";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1401, 615);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.btnContaLetras);
            this.Controls.Add(this.btnPrimeiroCarac);
            this.Controls.Add(this.btnContaNumeros);
            this.Controls.Add(this.rctxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtFrase;
        private System.Windows.Forms.Button btnContaNumeros;
        private System.Windows.Forms.Button btnPrimeiroCarac;
        private System.Windows.Forms.Button btnContaLetras;
        private System.Windows.Forms.Label lblFrase;
    }
}